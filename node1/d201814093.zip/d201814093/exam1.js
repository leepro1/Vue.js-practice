// print 함수 구현
function print(a){
    return console.log(typeof a);
}

print(true); 
print("hello world"); 
print();